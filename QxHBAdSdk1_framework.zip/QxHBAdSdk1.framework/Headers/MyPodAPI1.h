//
//  MyPodAPI1.h
//  Pods-QxHBAdSdk1_Example
//
//  Created by frank.zheng on 12/12/2017.
//

#import <Foundation/Foundation.h>

@interface MyPodAPI1 : NSObject

-(void)sayHello:(NSString*)name;


@end
